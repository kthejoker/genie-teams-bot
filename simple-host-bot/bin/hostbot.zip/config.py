#!/usr/bin/env python3
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

import os
from typing import Dict
from botbuilder.core.skills import BotFrameworkSkill


class DefaultConfig:
    """ Bot Configuration """

    def __init__(self, env, bot_prefix) -> None:
        print(env)
        self.env = env
        if bot_prefix is not None:
            self.BOT_PREFIX = bot_prefix

    env = "prod"
    BOT_PREFIX=os.environ.get("BOT_PREFIX", "genie")
    
    PORT = 3978
    APP_ID = os.environ.get("MicrosoftAppId", "")
    APP_PASSWORD = os.environ.get("MicrosoftAppPassword", "")
    APP_TYPE = "MultiTenant"
    APP_TENANTID = os.environ.get("MicrosoftAppTenantId", "")
    
    envs = { 
                "local-to-prod" : {
            "endpoint" : f"http://localhost:{PORT}/api/skills",
             "skill_bot_url" : f"{BOT_PREFIX}-genie-skill-001.azurewebsites.net"
        },
        "prod" : {
            "endpoint" : f"http://{BOT_PREFIX}-geniebot-001.azurewebsites.net/api/skills",
             "skill_bot_url" : f"{BOT_PREFIX}-genie-skill-001.azurewebsites.net"
        },
         "local" : {
            "endpoint" : f"http://localhost:{PORT}/api/skills",
             "skill_bot_url" : "localhost:39783"
        }
    }

    SKILL_HOST_ENDPOINT = envs[env]["endpoint"]

    print(SKILL_HOST_ENDPOINT)
    SKILLS = [
        {
            "id": "SkillBot",
            "app_id": "5afff072-da4e-4ba2-9e3e-6b8a79554967",
            "skill_endpoint": f'http://{envs[env]["skill_bot_url"]}/api/messages',
        },
    ]

    ALLOWED_CALLERS = os.environ.get("AllowedCallers", ["*"])


class SkillConfiguration:
    SKILL_HOST_ENDPOINT = DefaultConfig.SKILL_HOST_ENDPOINT
    SKILLS: Dict[str, BotFrameworkSkill] = {
        skill["id"]: BotFrameworkSkill(**skill) for skill in DefaultConfig.SKILLS
    }
