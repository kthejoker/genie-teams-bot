# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from .allowed_callers_claims_validator import AllowedCallersClaimsValidator

__all__ = ["AllowedCallersClaimsValidator"]
