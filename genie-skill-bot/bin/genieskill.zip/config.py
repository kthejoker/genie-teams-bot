#!/usr/bin/env python3
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

import os


class DefaultConfig:
    """ Bot Configuration """

    PORT = 39783
    APP_ID = os.environ.get("MicrosoftAppId", "")
    APP_PASSWORD = os.environ.get("MicrosoftAppPassword", "")
    APP_TYPE = os.environ.get("MicrosoftAppType", "MultiTenant")
    APP_TENANTID = os.environ.get("MicrosoftAppTenantId", "")
    CONNECTION_NAME = os.environ.get("ConnectionName", "")
    DATABRICKS_SPACE_ID=os.environ.get("DATABRICKS_SPACE_ID", "") # "01ef3055390e110b9bb70cca1c8c7a3e"
    DATABRICKS_HOST=os.environ.get("DATABRICKS_HOST", "") # "https://adb-984752964297111.11.azuredatabricks.net/"
    DATABRICKS_TOKEN=os.environ.get("DATABRICKS_TOKEN", "") # "dapi0824de426068584b18584d54e80448cc"

    # Callers to only those specified, '*' allows any caller.
    # Example: os.environ.get("AllowedCallers", ["aaaaaa-1111-1111-1111-aaaaaaaaaa"])
    ALLOWED_CALLERS = os.environ.get("AllowedCallers", ["*"])
